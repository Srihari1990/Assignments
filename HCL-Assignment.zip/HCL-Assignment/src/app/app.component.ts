import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

export interface FilteredData{
  lat: number;
  lng: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  encapsulation:ViewEncapsulation.None
})
export class AppComponent implements OnInit{

  formGroup: FormGroup;
  constructor(private formBuilder: FormBuilder, private httpClient:HttpClient) { }

  ngOnInit() {
    this.createForm();
  }

  createForm() {
    this.formGroup = this.formBuilder.group({
      'cityname': ['', Validators.required],
    });
  }

  getError(el) {
    switch (el) {
      case 'user':
        if (this.formGroup.get('cityname').hasError('required')) {
          return 'City Name is required';
        }
        break;
      default:
        return '';
    }
  }

  public selectedCity;
  selectedData;
  filteredData: FilteredData[] = [];

  onSubmitCity(post) {
     this.selectedCity = post.cityname;
     console.log(this.selectedCity);
     this.httpClient.get(`http://www.datasciencetoolkit.org/maps/api/geocode/json?sensor=false&address=${this.selectedCity}`)
     .subscribe(
       (data:any[]) => {
       this.selectedData = data;
       this.filteredData = [];
       this.filteredData.push(this.selectedData.results[0].geometry.location);
       console.log(this.filteredData[0].lng);
     })
  }

}